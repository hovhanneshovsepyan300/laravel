<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <section class="content-header">
            <h1>
                Order info
                <small>Control panel</small>
            </h1>
            <ol class="breadcrumb">
                <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
                <li class="active">Order info</li>
            </ol>
        </section>

        <section class="content">
            <div class="row">
                <div class="col-md-6">

                    <div class="form-group">
                        <label for="name">Name:</label>
                        <p><?php echo e($order->name); ?></p>
                    </div>

                    <div class="form-group">
                        <label for="description">Delivery:</label>
                        <p><?php echo e($order->delivery->delivery_date); ?></p>
                    </div>

                    <div class="form-group">
                        <label for="model_text">Email:</label>
                        <p><?php echo e($order->email); ?></p>
                    </div>

                    <div class="form-group">
                        <label for="colli_size">User:</label>
                        <p><?php echo e($order->user->name); ?></p>
                        <p><?php echo e($order->user->email); ?></p>
                    </div>

                    <div class="form-group">
                        <label for="skeeis_item_number">Mobile:</label>
                        <p><?php echo e($order->mobile); ?></p>
                    </div>

                    <div class="form-group">
                        <label for="pharmacy_item_number">Address:</label>
                        <p><?php echo e($order->address); ?></p>
                    </div>

                </div>

                <div class="col-md-6">

                    <?php
                        $total_price = 0;
                        $total_amount = 0;
                    ?>

                    <div class="form-group">
                        <label for="description">Delivery:</label>
                        <p><?php echo e($order->delivery->delivery_date); ?></p>
                    </div>

                    <div class="form-group">
                        <label for="name">Products:</label>
                        <?php $__currentLoopData = $order->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <p>Name: <a href="<?php echo e(url('administration/products/'. $product->id )); ?>"><?php echo e($product->name); ?></a></p>

                            <?php
                                $total_price = $total_price + $product->pivot->price;
                                $total_amount = $total_amount + $product->pivot->amount;
                            ?>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>

                    <div class="form-group">
                        <label for="pharmacy_item_number">Total amount:</label>
                        <p><?php echo e($total_amount); ?></p>
                    </div>

                    <div class="form-group">
                        <label for="pharmacy_item_number">Total price:</label>
                        <p><?php echo e($total_price); ?></p>
                    </div>

                </div>
                
            </div>
        </section>
    </div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('admin.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\skee\resources\views/admin/order/show.blade.php ENDPATH**/ ?>