<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <section class="content-header">
            <h1>
                Invoice
                <small>Control panel</small>
            </h1>
            <ol class="breadcrumb">
                <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
                <li class="active">Invoice</li>
            </ol>
        </section>

        <section class="content">
            <div class="row">
                <section class="content">
                    <div class="row">
                        <div class="col-xs-12">

                            <div class="box">
                                <div class="box-header">
                                    <h3 class="box-title">Invoice Table</h3>
                                </div>
                                <div class="box-body">
                                    <table id="example1" class="table table-bordered table-striped faqs-table">
                                        <thead>
                                        <tr>
                                            <th>Draft Invoice Number</th>
                                            <th>Currency</th>
                                            <th>Due Date</th>
                                            <th>Created At</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $invoice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td>
                                                        <a href="<?php echo e(url('administration/invoices/'.$invoice['draftInvoiceNumber'])); ?>"><?php echo e($invoice['draftInvoiceNumber']); ?></a>
                                                    </td>
                                                    <td><?php echo e($invoice['currency']); ?></td>
                                                    <td><?php echo e($invoice['dueDate']); ?></td>
                                                    <td><?php echo e($invoice['date']); ?></td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                        <tfoot>
                                        <tr>
                                            <th>Draft Invoice Number</th>
                                            <th>Currency</th>
                                            <th>Due Date</th>
                                            <th>Created At</th>
                                        </tr>
                                        </tfoot>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
            </div>
        </section>
    </div>


<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('admin.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\skee\resources\views/admin/invoice/index.blade.php ENDPATH**/ ?>