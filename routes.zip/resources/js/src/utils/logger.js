export const log = (message) => console.log(message);
export const warn = (message) => console.warn(message);
export const dir = (message) => console.dir(message);
export const info = (message) => console.info(message);