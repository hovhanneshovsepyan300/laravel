import React from "react";
import Master from "./routing/master";


class App extends React.Component {
  render() {
    return (
      <Master />
    );
  }
}

export default App;
