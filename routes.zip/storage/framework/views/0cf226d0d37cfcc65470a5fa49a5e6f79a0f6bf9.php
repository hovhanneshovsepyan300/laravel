<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <section class="content-header">
            <h1>
                Invoice info
                <small>Control panel</small>
            </h1>
            <ol class="breadcrumb">
                <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
                <li class="active">Invoice info</li>
            </ol>
        </section>

        <section class="content">
            <div class="row">
                <div class="col-md-4">
                    <div class="form-group">
                        <label for="date">Date:</label>
                        <p><?php echo e($invoice['date']); ?></p>
                    </div>

                    <div class="form-group">
                        <label for="dueDate">Due Date:</label>
                        <p><?php echo e($invoice['dueDate']); ?></p>
                    </div>

                    <div class="form-group">
                        <label for="currency">Currency:</label>
                        <p><?php echo e($invoice['currency']); ?></p>
                    </div>

                    <div class="form-group">
                        <label for="exchangeRate">Exchange Rate:</label>
                        <p><?php echo e($invoice['exchangeRate']); ?></p>
                    </div>

                    <div class="form-group">
                        <label for="netAmount">Net Amount:</label>
                        <p><?php echo e($invoice['netAmount']); ?></p>
                    </div>

                    <div class="form-group">
                        <label for="vatAmount">Vat Amount:</label>
                        <p><?php echo e($invoice['vatAmount']); ?></p>
                    </div>
                </div>

                <div class="col-md-4">
                    <div class="form-group">
                        <label for="customer">Customer:</label>
                        <p>Customer Number: <?php echo e($invoice['customer']['customerNumber']); ?></p>
                    </div>

                    <div class="form-group">
                        <label for="recipient">Recipient:</label>
                        <p>Recipient Name: <?php echo e($invoice['recipient']['name']); ?></p>
                        <p>Recipient Address: <?php echo e(isset($invoice['recipient']['address']) ? $invoice['recipient']['address'] : ''); ?></p>
                        <p>Recipient City: <?php echo e(isset($invoice['recipient']['city']) ? $invoice['recipient']['city'] : ''); ?></p>
                    </div>

                    <div class="form-group">
                        <label for="lines">Lines:</label>
                        <?php if(isset($invoice['lines'])): ?>
                            <?php $__currentLoopData = $invoice['lines']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $line): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <p>Lines Number: <?php echo e($line['lineNumber']); ?></p>
                                <p>Lines Product Number: <?php echo e($line['product']['productNumber']); ?></p>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </section>
    </div>

<?php $__env->stopSection(); ?>






<?php echo $__env->make('admin.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('admin.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\skee\resources\views/admin/invoice/show.blade.php ENDPATH**/ ?>