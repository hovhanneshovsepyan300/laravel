<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Traits\ClientErrorTrait;
use Illuminate\Http\Request;

class ApiController extends Controller
{
    use ClientErrorTrait;
}