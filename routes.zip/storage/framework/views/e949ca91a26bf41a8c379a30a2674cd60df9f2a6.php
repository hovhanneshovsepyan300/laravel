<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <section class="content-header">
            <h1>
                Order info
                <small>Control panel</small>
            </h1>
            <ol class="breadcrumb">
                <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
                <li class="active">Order info</li>
            </ol>
        </section>

        <section class="content">
            <div class="row">
                <div class="col-md-4">
                    <div class="form-group">
                        <label for="date">Date:</label>
                        <p><?php echo e($order['date']); ?></p>
                    </div>

                    <div class="form-group">
                        <label for="dueDate">Due Date:</label>
                        <p><?php echo e($order['dueDate']); ?></p>
                    </div>

                    <div class="form-group">
                        <label for="currency">Currency:</label>
                        <p><?php echo e($order['currency']); ?></p>
                    </div>

                    <div class="form-group">
                        <label for="exchangeRate">Exchange Rate:</label>
                        <p><?php echo e($order['exchangeRate']); ?></p>
                    </div>

                    <div class="form-group">
                        <label for="netAmount">Net Amount:</label>
                        <p><?php echo e($order['netAmount']); ?></p>
                    </div>

                    <div class="form-group">
                        <label for="vatAmount">Vat Amount:</label>
                        <p><?php echo e($order['vatAmount']); ?></p>
                    </div>
                </div>

                <div class="col-md-4">
                    <div class="form-group">
                        <label for="customer">Customer:</label>
                        <p>Customer Number: <?php echo e($order['customer']['customerNumber']); ?></p>
                    </div>

                    <?php if(isset($order['recipient'])): ?>
                        <div class="form-group">
                            <label for="recipient">Recipient:</label>
                            <p>Recipient Name: <?php echo e($order['recipient']['name']); ?></p>
                            <p>Recipient Address: <?php echo e(isset($order['recipient']['address']) ? $order['recipient']['address'] : ''); ?></p>
                            <p>Recipient City: <?php echo e(isset($order['recipient']['city']) ? $order['recipient']['city'] : ''); ?></p>
                            <p>Recipient Zip: <?php echo e(isset($order['recipient']['zip']) ? $order['recipient']['zip'] : ''); ?></p>
                        </div>
                    <?php endif; ?>

                    <?php if(isset($order['lines'])): ?>
                        <div class="form-group">
                            <label for="lines">Lines:</label>
                            <?php if(isset($order['lines'])): ?>
                                <?php $__currentLoopData = $order['lines']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $line): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <p>Lines Number: <?php echo e($line['lineNumber']); ?></p>
                                    <p>Lines Product Number: <?php echo e($line['product']['productNumber']); ?></p>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>

                </div>

            </div>
        </section>
    </div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('admin.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\skee\resources\views/admin/order/economic-show.blade.php ENDPATH**/ ?>