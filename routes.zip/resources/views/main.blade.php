@extends('react_header')

@section('content')
    <div id="root"></div>
@endsection

@section('scripts')
    <script src="{{ asset('js/index.js') }}"></script>
@endsection