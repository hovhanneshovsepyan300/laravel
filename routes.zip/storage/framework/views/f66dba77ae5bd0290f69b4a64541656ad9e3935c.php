<?php $__env->startSection('menu'); ?>

<section class="sidebar">
    <!-- Sidebar user panel -->
    <div class="user-panel" style="height: 40px">
        <div class="pull-left info">
            <p><?php echo e(auth()->user()->name); ?> <span><i class="fa fa-circle text-success"></i> Online</span></p>
        </div>
    </div>

    <ul class="sidebar-menu" data-widget="tree">
        <li class="header">MAIN NAVIGATION</li>

        <li>
            <a href="<?php echo e(url('/administration/dashboard')); ?>">
                <i class="fa fa-dashboard"></i> <span>Dashboard</span>
            </a>
        </li>

        <li class="treeview <?php echo e((request()->segment(2) == 'users') ? 'menu-open' : ''); ?>">
            <a href="#">
                <i class="fa fa-user"></i>
                <span>Users</span>
                <span class="pull-right-container">
            </span>
            </a>
            <ul class="treeview-menu" style="<?php echo e((request()->segment(2) == 'users') ? 'display:block' : ''); ?>">
                <li><a href="<?php echo e(url('/administration/users')); ?>"><i class="fa fa-circle-o"></i> User List</a></li>
                <li><a href="<?php echo e(url('/administration/users/create')); ?>"><i class="fa fa-circle-o"></i> Add user</a></li>
            </ul>
        </li>

        <li class="treeview <?php echo e((request()->segment(2) == 'products') ? 'menu-open' : ''); ?>">
            <a href="#">
                <i class="fa fa-product-hunt" aria-hidden="true"></i>
                <span>Products</span>
                <span class="pull-right-container">
            </span>
            </a>
            <ul class="treeview-menu" style="<?php echo e((request()->segment(2) == 'products') ? 'display:block' : ''); ?>">
                <li><a href="<?php echo e(url('/administration/products')); ?>"><i class="fa fa-circle-o"></i> Product List</a></li>
                <li><a href="<?php echo e(url('/administration/products/create')); ?>"><i class="fa fa-circle-o"></i> Add Product</a></li>
            </ul>
        </li>

        <li class="treeview <?php echo e((request()->segment(2) == 'deliveries') ? 'menu-open' : ''); ?>">
            <a href="#">
                <i class="fa fa-calendar" aria-hidden="true"></i>
                <span>Delivery</span>
                <span class="pull-right-container">
            </span>
            </a>
            <ul class="treeview-menu" style="<?php echo e((request()->segment(2) == 'deliveries') ? 'display:block' : ''); ?>">
                <li><a href="<?php echo e(url('/administration/deliveries')); ?>"><i class="fa fa-circle-o"></i> Delivery List</a></li>
                <li><a href="<?php echo e(url('/administration/deliveries/create')); ?>"><i class="fa fa-circle-o"></i> Add Delivery</a></li>
            </ul>
        </li>

        <li class="treeview <?php echo e((request()->segment(2) == 'faqs') ? 'menu-open' : ''); ?>">
            <a href="#">
                <i class="fa fa-question-circle" aria-hidden="true"></i>
                <span>FAQ</span>
                <span class="pull-right-container">
            </span>
            </a>
            <ul class="treeview-menu" style="<?php echo e((request()->segment(2) == 'faqs') ? 'display:block' : ''); ?>">
                <li><a href="<?php echo e(url('/administration/faqs')); ?>"><i class="fa fa-circle-o"></i> FAQ List</a></li>
                <li><a href="<?php echo e(url('/administration/faqs/create')); ?>"><i class="fa fa-circle-o"></i> Add FAQ</a></li>
            </ul>
        </li>

        <li class="treeview <?php echo e((request()->segment(2) == 'orders') ? 'menu-open' : ''); ?>">
            <a href="#">
                <i class="fa fa-first-order" aria-hidden="true"></i>
                <span>Orders</span>
                <span class="pull-right-container">
            </span>
            </a>
            <ul class="treeview-menu" style="<?php echo e((request()->segment(2) == 'orders') ? 'display:block' : ''); ?>">
                <li><a href="<?php echo e(url('/administration/orders')); ?>"><i class="fa fa-circle-o"></i> Order List</a></li>


            </ul>
        </li>




























        <li class="treeview <?php echo e((request()->segment(2) == 'invoices') ? 'menu-open' : ''); ?>">
            <a href="#">
                <i class="fa fa-tasks" aria-hidden="true"></i>
                <span>Invoice</span>
                <span class="pull-right-container">
            </span>
            </a>
            <ul class="treeview-menu" style="<?php echo e((request()->segment(2) == 'invoices') ? 'display:block' : ''); ?>">
                <li><a href="<?php echo e(url('/administration/invoices')); ?>"><i class="fa fa-circle-o"></i>Invoice List</a></li>
                <li><a href="<?php echo e(url('/administration/invoices/create')); ?>"><i class="fa fa-circle-o"></i>Create Invoice</a></li>
            </ul>
        </li>

        <li class="treeview <?php echo e((request()->segment(2) == 'packages') ? 'menu-open' : ''); ?>">
            <a href="#">
                <i class="fa fa-tasks" aria-hidden="true"></i>
                <span>Package delivery</span>
                <span class="pull-right-container">
            </span>
            </a>
            <ul class="treeview-menu" style="<?php echo e((request()->segment(2) == 'packages') ? 'display:block' : ''); ?>">
                <li><a href="<?php echo e(url('/administration/packages')); ?>"><i class="fa fa-circle-o"></i>Package delivery list</a></li>
                <li><a href="<?php echo e(url('/administration/packages/create')); ?>"><i class="fa fa-circle-o"></i>Create package delivery</a></li>
            </ul>
        </li>

    </ul>
</section>

<?php $__env->stopSection(); ?><?php /**PATH C:\xampp\htdocs\skee\resources\views/admin/menu.blade.php ENDPATH**/ ?>