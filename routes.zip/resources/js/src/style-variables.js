const StyleVariables = {
    defaultFontColor: '#414b56'
}

export default StyleVariables;