<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <section class="content-header">
            <h1>
                Economic
                <small>Control panel</small>
            </h1>
            <ol class="breadcrumb">
                <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
                <li class="active">Economic</li>
            </ol>
        </section>

        <section class="content">
            <div class="row">
                <section class="content">
                    <div class="row">
                        <div class="col-xs-12">

                            <?php if($errors->any()): ?>
                                <div class="alert alert-danger">
                                    <ul>
                                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li><?php echo e($error); ?></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>
                            <?php endif; ?>

                            <?php if(Session::has('message')): ?>
                                <div class="alert alert-success"><?php echo e(Session::get('message')); ?></div>
                            <?php endif; ?>

                            <div class="box">
                                <div class="box-header">
                                    <h3 class="box-title">Economic customers Table</h3>
                                </div>
                                <div class="box-body">
                                    <table id="example1" class="table table-bordered table-striped faqs-table">
                                        <thead>
                                        <tr>
                                            <th>Customer Number</th>
                                            <th>Name</th>
                                            <th>Email</th>
                                            <th>Currency</th>
                                            <th>Import</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($customer['customerNumber']); ?></td>
                                                <td><?php echo e($customer['name']); ?></td>
                                                <td><?php echo e((array_key_exists('email',$customer)?$customer['email']:'')); ?></td>
                                                <td><?php echo e($customer['currency']); ?></td>
                                                <td style="text-align: center">
                                                    <?php if($customer['customerExists']): ?>
                                                        <p style="color: #a5a5a5;font-size: 13px;">Imported!</p>
                                                    <?php else: ?>
                                                        <?php if(array_key_exists('email',$customer) && $customer['email']): ?>
                                                            <a style="text-align: center" href="<?php echo e(url("/administration/economics/customers/import/".$customer['customerNumber'])); ?>">
                                                                <i class="fa fa-cloud-download" aria-hidden="true"></i>
                                                            </a>
                                                        <?php endif; ?>
                                                    <?php endif; ?>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                        <tfoot>
                                        <tr>
                                            <th>Customer Number</th>
                                            <th>Name</th>
                                            <th>Email</th>
                                            <th>Currency</th>
                                            <th>Import</th>
                                        </tr>
                                        </tfoot>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
            </div>
        </section>
    </div>


<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('admin.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\skee\resources\views/admin/economic/index.blade.php ENDPATH**/ ?>