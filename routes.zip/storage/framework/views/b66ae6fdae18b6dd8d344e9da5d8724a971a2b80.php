<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <section class="content-header">
            <h1>
                User
                <small>User panel</small>
            </h1>
            <ol class="breadcrumb">
                <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
                <li class="active">User</li>
            </ol>
            <br>
            <a href="<?php echo e(url('administration/users/economic/import')); ?>" class="btn btn-success">Import from E-conomics</a>
        </section>

        <section class="content">
            <div class="row">
                <section class="content">
                    <div class="row">
                        <div class="col-xs-12">

                            <div class="box">
                                <div class="box-header">
                                    <h3 class="box-title">User Table</h3>
                                </div>
                                <div class="box-body">
                                    <table id="example1" class="table table-bordered table-striped users-table">
                                        <thead>
                                        <tr>
                                            <th>Name</th>
                                            <th>Email</th>
                                            <th>Add to Economic</th>
                                            <th>Created At</th>
                                            <th>Edit</th>
                                            <th>Delete</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr data-number="<?php echo e($user->id); ?>">
                                                <td><a href="<?php echo e(url('administration/users/'. $user->id )); ?>"><?php echo e($user->name); ?></a></td>
                                                <td><?php echo e($user->email); ?></td>
                                                <td style="cursor: pointer">
                                                    <?php if($user->customer_number): ?>
                                                        <a style="color:darkred;font-weight: 800" href="<?php echo e(url('administration/users/economic/delete/'. $user->id )); ?>">Delete from E-conomic</a>
                                                    <?php else: ?>
                                                        <a style="color:darkgreen;font-weight: 800" href="<?php echo e(url('administration/users/economic/'. $user->id )); ?>">Add to E-conomic</a>
                                                    <?php endif; ?>

                                                </td>
                                                <td><?php echo e($user->created_at->format('d-m-Y')); ?></td>
                                                <td>
                                                    <a href="<?php echo e(url("/administration/users/$user->id/edit")); ?>"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a>
                                                </td>
                                                <td class="delete-user-item" data-id="<?php echo e($user->id); ?>">
                                                    <i class="fa fa-trash" aria-hidden="true"></i>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                        <tfoot>
                                        <tr>
                                            <th>Name</th>
                                            <th>Email</th>
                                            <th>Add to Economic</th>
                                            <th>Created At</th>
                                            <th>Edit</th>
                                            <th>Delete</th>
                                        </tr>
                                        </tfoot>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
            </div>
        </section>
    </div>


<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('admin.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\skee\resources\views/admin/user/index.blade.php ENDPATH**/ ?>