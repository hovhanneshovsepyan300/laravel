<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <section class="content-header">
            <h1>
                Export orders to invoice
                <small>Control panel</small>
            </h1>
            <ol class="breadcrumb">
                <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
                <li class="active">Export orders to invoice</li>
            </ol>
        </section>

        <section class="content">
                <div class="row">
                    <div class="col-xs-12">

                        <?php if(Session::has('message')): ?>
                            <div class="alert alert-success"><?php echo e(Session::get('message')); ?></div>
                        <?php endif; ?>

                        <div class="row">
                            <div class="col-xs-12">
                                <p> Start:<?php echo e($last_month_info['start']); ?></p>
                                <p> End:  <?php echo e($last_month_info['end']); ?></p>
                                <p> Month: <?php echo e($last_month_info['month']['number'] .' / '. $last_month_info['month']['name']); ?></p>
                            </div>
                        </div>

                        <form method="POST" action="<?php echo e(route('exportOrdersToInvoice')); ?>">
                            <?php echo csrf_field(); ?>
                            <button class="btn btn-success">Export orders to invoice</button>
                        </form>
                        <br>


                        <div class="box">

                            <div class="box-header">
                                <h3 class="box-title">Order Table</h3>
                            </div>
                            <div class="box-body">
                                <table class="table table-bordered table-striped">
                                    <thead>
                                    <tr>
                                        <th>Name</th>
                                        <th>Price</th>
                                        <th>Delivery</th>
                                        <th>Exported</th>
                                        <th>Created At</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr data-number="<?php echo e($order->id); ?>">
                                            <td><a href="<?php echo e(url('administration/orders/'. $order->id )); ?>"><?php echo e($order->name); ?></a></td>
                                            <td><?php echo e(Str::replaceFirst('.', ',', $order->products[0]->price)); ?></td>
                                            <td>
                                                <?php echo e(date('d-m-Y', strtotime($order->delivery->delivery_date))); ?>

                                            </td>
                                            <th>
                                                <?php if($order->economic_status): ?>
                                                    <i class="fa fa-check" aria-hidden="true"></i>
                                                <?php else: ?>

                                                <?php endif; ?>
                                            </th>
                                            <td><?php echo e($order->created_at->format('d-m-Y')); ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                    <tfoot>
                                    <tr>
                                        <th>Name</th>
                                        <th>Price</th>
                                        <th>Delivery</th>
                                        <th>Exported</th>
                                        <th>Created At</th>
                                    </tr>
                                    </tfoot>
                                </table>
                            </div>

                        </div>

                    </div>
                </div>
        </section>
    </div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('admin.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\skee\resources\views/economic/invoice.blade.php ENDPATH**/ ?>