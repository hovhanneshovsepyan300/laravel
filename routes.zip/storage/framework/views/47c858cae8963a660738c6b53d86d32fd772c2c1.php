<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <section class="content-header">
            <h1>
                User info
                <small>Control panel</small>
            </h1>
            <ol class="breadcrumb">
                <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
                <li class="active">User info</li>
            </ol>
        </section>

        <section class="content">
            <div class="row">
                <div class="col-md-6">

                        <div class="form-group">
                            <label for="name">Name:</label>
                            <p><?php echo e($user->name); ?></p>
                        </div>

                        <div class="form-group">
                            <label for="email">Email:</label>
                            <p><?php echo e($user->email); ?></p>
                        </div>

                        <div class="form-group">
                            <label for="tel">Tel:</label>
                            <p><?php echo e($user->tel); ?></p>
                        </div>

                        <div class="form-group">
                            <label for="tel">Address:</label>
                            <p><?php echo e($user->address); ?></p>
                        </div>

                        <div class="form-group">
                            <label for="zip">Zip:</label>
                            <p><?php echo e($user->zip); ?></p>
                        </div>

                        <div class="form-group">
                            <label for="city">City:</label>
                            <p><?php echo e($user->city); ?></p>
                        </div>

                        <div class="form-group">
                            <label for="customer_number">Customer number:</label>
                            <p><?php echo e($user->customer_number); ?></p>
                        </div>

                        <div class="form-group">
                            <label for="primary_contact">Primary contact:</label>
                            <p><?php echo e($user->primary_contact); ?></p>
                        </div>
                </div>

            </div>
        </section>

    </div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('admin.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\skee\resources\views/admin/user/show.blade.php ENDPATH**/ ?>