<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <section class="content-header">
            <h1>
                Product info
                <small>Control panel</small>
            </h1>
            <ol class="breadcrumb">
                <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
                <li class="active">Product info</li>
            </ol>
        </section>

        <section class="content">
            <div class="row">
                <div class="col-md-6">

                    <div class="form-group">
                        <label for="name">Name:</label>
                        <p><?php echo e($product->name); ?></p>
                    </div>

                    <div class="form-group">
                        <label for="description">Description:</label>
                        <p><?php echo e($product->description); ?></p>
                    </div>

                    <div class="form-group">
                        <label for="colli_size">Colli size:</label>
                        <p><?php echo e($product->colli_size); ?></p>
                    </div>

                    <div class="form-group">
                        <label for="size">Size:</label>
                        <p><?php echo e($product->size); ?></p>
                    </div>

                    <div class="form-group">
                        <label for="model_text">Model text:</label>
                        <p><?php echo e($product->model_text); ?></p>
                    </div>

                    <div class="form-group">
                        <label for="skeeis_item_number">Skeeis item number:</label>
                        <p><?php echo e($product->skeeis_item_number); ?></p>
                    </div>

                    <div class="form-group">
                        <label for="pharmacy_item_number">Pharmacy item number:</label>
                        <p><?php echo e($product->pharmacy_item_number); ?></p>
                    </div>

                    <div class="form-group">
                        <label for="type">Type:</label>
                        <p><?php echo e($product->type); ?></p>
                    </div>

                    <div class="form-group">
                        <label for="price">Price:</label>
                        <p><?php echo e($product->price); ?></p>
                    </div>

                    <div class="form-group">
                        <label for="price">Weight:</label>
                        <p><?php echo e($product->weight); ?></p>
                    </div>

                    <div class="form-group">
                        <label for="price">Images:</label>
                        <br>
                        <?php if($product->images): ?>
                            <?php $__currentLoopData = $product->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <img src="<?php echo e('/storage/uploads/' . $image->filename); ?>" style="width: 120px" alt="">
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </div>

                </div>
            </div>
        </section>
    </div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('admin.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\skee\resources\views/admin/product/show.blade.php ENDPATH**/ ?>